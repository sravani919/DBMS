// Code by Pragathi Pendem and Sravani Pati
package cpsc4620;

import java.io.IOException;
import java.sql.*;
import java.util.*;
import java.util.Date;

/*
 * This file is where most of your code changes will occur You will write the code to retrieve
 * information from the database, or save information to the database
 *
 * The class has several hard coded static variables used for the connection, you will need to
 * change those to your connection information
 *
 * This class also has static string variables for pickup, delivery and dine-in. If your database
 * stores the strings differently (i.e "pick-up" vs "pickup") changing these static variables will
 * ensure that the comparison is checking for the right string in other places in the program. You
 * will also need to use these strings if you store this as boolean fields or an integer.
 *
 *
 */

/**
 * A utility class to help add and retrieve information from the database
 */

public final class DBNinja {
	private static Connection conn;

	// Change these variables to however you record dine-in, pick-up and delivery, and sizes and crusts
	public final static String pickup = "pickup";
	public final static String delivery = "delivery";
	public final static String dine_in = "dinein";

	public final static String size_s = "Small";
	public final static String size_m = "Medium";
	public final static String size_l = "Large";
	public final static String size_xl = "XLarge";

	public final static String crust_thin = "Thin";
	public final static String crust_orig = "Original";
	public final static String crust_pan = "Pan";
	public final static String crust_gf = "Gluten-Free";


	private static boolean connect_to_db() throws SQLException, IOException {

		try {
			conn = DBConnector.make_connection();
			return true;
		} catch (SQLException e) {
			return false;
		} catch (IOException e) {
			return false;
		}

	}


	public static void addOrder(Order o) throws SQLException, IOException {

		/*
		 * add code to add the order to the DB. Remember that we're not just
		 * adding the order to the order DB table, but we're also recording
		 * the necessary data for the delivery, dinein, and pickup tables
		 *
		 */
		try{
			connect_to_db();
			String sql="";
			String insertType="";
			int tNum=0;
			if(o.getOrderID()==0) {
				sql = "insert into ordert(OrdertCustomerID, OrdertTimeStamp, OrdertCustomerPrice,OrdertBusinessPrice,OrdertType,IsCompleted) values(?, ?, ?,?,?,?)";

				PreparedStatement preparedStatement = conn.prepareStatement(sql);
				preparedStatement.setInt(1, o.getCustID());
				preparedStatement.setString(2, o.getDate());
				preparedStatement.setDouble(3, o.getCustPrice());
				preparedStatement.setDouble(4, o.getBusPrice());
				preparedStatement.setString(5, o.getOrderType());
				preparedStatement.setInt(6, o.getIsComplete());
				preparedStatement.executeUpdate();
				int maxOrderID=DBNinja.getLastOrder().getOrderID();
				if (o instanceof DineinOrder) {
					connect_to_db();
					insertType = "INSERT INTO dinein" + "(DineInOrderID,DineInTableNumber) " + "VALUES (?, ?)";
					DineinOrder dineinOrder = (DineinOrder) o;
					tNum = dineinOrder.getTableNum();
					PreparedStatement preparedDineIn = conn.prepareStatement(insertType);
					preparedDineIn.setInt(1, maxOrderID);
					preparedDineIn.setInt(2, tNum);
					preparedDineIn.executeUpdate();
				} else if(o instanceof PickupOrder) {
					connect_to_db();
					insertType = "INSERT INTO pickup" + "(PickUpOrderID) " + "VALUES (?)";

					PreparedStatement preparedDineIn = conn.prepareStatement(insertType);

					preparedDineIn.setInt(1,maxOrderID);
				}
				else{
					connect_to_db();
					insertType = "INSERT INTO delivery" + "(DeliveryOrderID) " + "VALUES (?)";


					PreparedStatement preparedDineIn = conn.prepareStatement(insertType);

					preparedDineIn.setInt(1, maxOrderID);


				}




			} else{
				String updateStatement = "update ordert set OrdertCustomerPrice=?,OrdertBusinessPrice=?, OrdertType=? where OrdertID=? " ;

				PreparedStatement preparedStatement = conn.prepareStatement(updateStatement);

				preparedStatement.setDouble(1, o.getCustPrice());
				preparedStatement.setDouble(2, o.getBusPrice());
				preparedStatement.setString(3, o.getOrderType());
				preparedStatement.setInt(4, o.getOrderID());

				preparedStatement.executeUpdate();
			}
			conn.close();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}


		//DO NOT FORGET TO CLOSE YOUR CONNECTION
	}

	public static void addPizza(Pizza p) throws SQLException, IOException {
		/*
		 * Add the code needed to insert the pizza into into the database.
		 * Keep in mind adding pizza discounts and toppings associated with the pizza,
		 * there are other methods below that may help with that process.
		 *
		 */
		try {
			connect_to_db();
			if(p.getPizzaID()==0) {
				String sql = "insert into pizza(PizzaOrderID, PizzaBusinessPrice, PizzaCustomerPrice,PizzaState,PizzaCrustType,PizzaSize) values(?, ?, ?,?,?,?)";

				PreparedStatement preparedStatement = conn.prepareStatement(sql);
				preparedStatement.setInt(1, p.getOrderID());
				preparedStatement.setDouble(2, p.getBusPrice());
				preparedStatement.setDouble(3, p.getCustPrice());
				preparedStatement.setString(4, p.getPizzaState());
				preparedStatement.setString(5, p.getCrustType());
				preparedStatement.setString(6, p.getSize());
				preparedStatement.executeUpdate();
				System.out.println("Pizza added ");
			}
			else{
				String updateStatement = "update pizza set PizzaCustomerPrice=?,PizzaBusinessPrice=? where PizzaID=? " ;

				PreparedStatement preparedStatement = conn.prepareStatement(updateStatement);

				preparedStatement.setDouble(1, p.getCustPrice());
				preparedStatement.setDouble(2, p.getBusPrice());

				preparedStatement.setInt(3, p.getPizzaID());

				preparedStatement.executeUpdate();
			}

			conn.close();
		}catch (Exception e) {
			e.printStackTrace();
		}
		finally {
			try {
				conn.close();
			}
			catch (SQLException e) {
				e.printStackTrace();
			}
		}


		//DO NOT FORGET TO CLOSE YOUR CONNECTION
	}


	public static void useTopping(Pizza p, Topping t, boolean isDoubled) throws SQLException, IOException //this method will update toppings inventory in SQL and add entities to the Pizzatops table. Pass in the p pizza that is using t topping
	{
		/*
		 * This method should do 2 two things.
		 * - update the topping inventory every time we use t topping (accounting for extra toppings as well)
		 * - connect the topping to the pizza
		 *   What that means will be specific to your yimplementatinon.
		 *
		 * Ideally, you should't let toppings go negative....but this should be dealt with BEFORE calling this method.
		 *
		 */
		try {
			connect_to_db();

			double AmountforSize = 0.0;
			if (p.getSize() == "Small") {
				AmountforSize = t.getPerAMT();
			} else if (p.getSize() == "Medium") {
				AmountforSize = t.getMedAMT();
			} else if (p.getSize() == "Large") {
				AmountforSize = t.getLgAMT();
			} else if (p.getSize() == "XLarge") {
				AmountforSize = t.getXLAMT();
			}

			if (isDoubled == true) {

				if (t.getCurINVT() - 2 * AmountforSize < 0) {
					System.out.println("We don't have enough of that topping to add it...");
				} else {
					String updateStatement = null;
					updateStatement = "update topping set ToppingCurrentInvLvl=ToppingCurrentInvLvl- " + 2 * AmountforSize + " where ToppingID= " + t.getTopID();
					PreparedStatement preparedStatement = conn.prepareStatement(updateStatement);
					preparedStatement.executeUpdate();
				}
			} else {
				if (t.getCurINVT() - AmountforSize < 0) {
					System.out.print("we run out of that topping");
				} else {
					String updateStatement = null;
					updateStatement = "update topping set ToppingCurrentInvLvl=ToppingCurrentInvLvl-" + AmountforSize + " where ToppingID= " + t.getTopID();
					PreparedStatement preparedStatement = conn.prepareStatement(updateStatement);
					preparedStatement.executeUpdate();
				}
			}
			String sql = "insert into pizzatopping(PizzaToppingPizzaID, PizzaToppingToppingID, PizzaToppingIsDouble) values(?, ?, ?)";

			PreparedStatement preparedStatement = conn.prepareStatement(sql);
			preparedStatement.setInt(1, p.getPizzaID());
			preparedStatement.setInt(2, t.getTopID());
			preparedStatement.setBoolean(3,isDoubled );
			preparedStatement.executeUpdate();
			System.out.println( p.getPizzaID()+" "+t.getTopID()+" "+isDoubled);


			conn.close();

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}

			//DO NOT FORGET TO CLOSE YOUR CONNECTION
		}
	}


	public static void usePizzaDiscount(Pizza p, Discount d) throws SQLException, IOException {
		connect_to_db();
		/*
		 * This method connects a discount with a Pizza in the database.
		 *
		 * What that means will be specific to your implementatinon.
		 */
		connect_to_db();
		try {
			String sql = "insert into specialpizzaoffer(SpecialPizzaOfferPizzaID, SpecialPizzaOfferDiscountID) values(?, ?)";

			PreparedStatement preparedStatement = conn.prepareStatement(sql);
			preparedStatement.setInt(1, p.getPizzaID());
			preparedStatement.setInt(2, d.getDiscountID());

			preparedStatement.executeUpdate();
			conn.close();
		}catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}


		//DO NOT FORGET TO CLOSE YOUR CONNECTION
	}

	public static void useOrderDiscount(Order o, Discount d) throws SQLException, IOException {

		/*
		 * This method connects a discount with an order in the database
		 *
		 * You might use this, you might not depending on where / how to want to update
		 * this information in the dabast
		 */
		connect_to_db();
		try {
			String sql = "insert into orderdeals(OrderDealsOrderID, OrderDealsDiscountID) values(?, ?)";
			System.out.print(o.getOrderID());
			PreparedStatement preparedStatement = conn.prepareStatement(sql);
			preparedStatement.setInt(1, o.getOrderID());
			preparedStatement.setInt(2, d.getDiscountID());

			preparedStatement.executeUpdate();
			conn.close();
		}catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		//DO NOT FORGET TO CLOSE YOUR CONNECTION
	}

	public static void addCustomer(Customer c) throws SQLException, IOException {
		connect_to_db();
		/*
		 * This method adds a new customer to the database.
		 *
		 */
		try {
//			String address=c.getAddress();
//			String[] addresses = address.trim().split("/");
//
//			String customerStreet=addresses[0];
//			String customerCity=addresses[1];
//			String customerState=addresses[2];
//			String customerPinCode=addresses[3];
			connect_to_db();
			String sql = "insert into customer(CustomerFirstName, CustomerLastName, CustomerPhoneNo) values(?, ?, ?)";
			PreparedStatement preparedStatement = conn.prepareStatement(sql);
			preparedStatement.setString(1, c.getFName());
			preparedStatement.setString(2, c.getLName());
			preparedStatement.setString(3, c.getPhone());
//			preparedStatement.setString(4,customerStreet );
//			preparedStatement.setString(5, customerCity);
//			preparedStatement.setString(6, customerState);
//			preparedStatement.setString(7, customerPinCode);
			preparedStatement.executeUpdate();
		}catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		//DO NOT FORGET TO CLOSE YOUR CONNECTION
	}

	public static void completeOrder(Order o) throws SQLException, IOException {
		/*
		 * Find the specifed order in the database and mark that order as complete in the database.
		 *
		 */

		try {
			connect_to_db();

			String updateStatement = "update ordert set IsCompleted = 1 where OrdertID = " + o.getOrderID() + " ;";

			PreparedStatement preparedStatement = conn.prepareStatement(updateStatement);

			preparedStatement.executeUpdate();
			String completed="Completed";
			String updatePizzaStatement = "update pizza set PizzaState = ?  where PizzaOrderID = ?" ;

			PreparedStatement pizzaPreparedStatement = conn.prepareStatement(updatePizzaStatement);
			pizzaPreparedStatement.setString(1,"Completed");
			pizzaPreparedStatement.setInt(2,o.getOrderID());

			pizzaPreparedStatement.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}


		//DO NOT FORGET TO CLOSE YOUR CONNECTION
	}


	public static ArrayList<Order> getOrders(boolean openOnly) throws SQLException, IOException {
		connect_to_db();
		/*
		 * Return an arraylist of all of the orders.
		 * 	openOnly == true => only return a list of open (ie orders that have not been marked as completed)
		 *           == false => return a list of all the orders in the database
		 * Remember that in Java, we account for supertypes and subtypes
		 * which means that when we create an arrayList of orders, that really
		 * means we have an arrayList of dineinOrders, deliveryOrders, and pickupOrders.
		 *
		 * Don't forget to order the data coming from the database appropriately.
		 *
		 */
		ArrayList<Order> orders = new ArrayList<Order>();

		try {
			connect_to_db();

			String selectQuery = "select * from ordert";
			if (openOnly) {
				selectQuery += " where (IsCompleted = false)";
			}
			selectQuery += " order by OrdertTimeStamp desc;";

			Statement statement = conn.createStatement();

			ResultSet record = statement.executeQuery(selectQuery);

			while (record.next()) {
				Integer orderId = record.getInt("OrdertID");
				String orderType = record.getString("OrdertType");
				Integer customerId = record.getInt("OrdertCustomerID");
				Double orderCost = record.getDouble("OrdertCustomerPrice");
				Double orderPrice = record.getDouble("OrdertBusinessPrice");
				String orderTimeStamp = record.getString("OrdertTimeStamp");
				Integer OrderCompleteState = record.getInt("IsCompleted");

				orders.add(
						new Order(orderId, customerId, orderType, orderTimeStamp, orderCost, orderPrice, OrderCompleteState));

			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}


		//DO NOT FORGET TO CLOSE YOUR CONNECTION
		return orders;
	}

	public static Order getLastOrder(){
		/*
		 * Query the database for the LAST order added
		 * then return an Order object for that order.
		 * NOTE...there should ALWAYS be a "last order"!
		 */

		Order lastOrder = null;
		try {
			connect_to_db();
			String maxOrdSql = "SELECT * FROM ordert ORDER BY OrdertID DESC LIMIT 1";
			PreparedStatement maxOrderstmt = conn.prepareStatement(maxOrdSql);
			ResultSet maxOrder = maxOrderstmt.executeQuery();

			if (maxOrder.next()) {
				// Retrieve order details
				int orderId = maxOrder.getInt("OrdertID");
				int custId = maxOrder.getInt("OrdertCustomerID");
				String orderType = maxOrder.getString("OrdertType");
				String date = maxOrder.getString("OrdertTimeStamp");
				double custPrice = maxOrder.getDouble("OrdertCustomerPrice");
				double busPrice = maxOrder.getDouble("OrdertBusinessPrice");
				int isComplete = maxOrder.getInt("IsCompleted");
				lastOrder = new Order(orderId, custId, orderType, date, custPrice, busPrice, isComplete);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return lastOrder;


	}

	public static ArrayList<Order> getOrdersByDate(String date){
		/*
		 * Query the database for ALL the orders placed on a specific date
		 * and return a list of those orders.
		 *
		 */
		ArrayList<Order> orders = new ArrayList<Order>();

		try {
			connect_to_db();

			String selectQuery = "select * from ordert";

			selectQuery += " where (OrdertTimeStamp >= '" + date + " 00:00:00')";

			selectQuery += " order by OrdertTimeStamp desc;";

			Statement statement = conn.createStatement();

			ResultSet record = statement.executeQuery(selectQuery);

			while (record.next()) {
				Integer orderId = record.getInt("OrdertID");
				String orderType = record.getString("OrdertType");
				Integer customerId = record.getInt("OrdertCustomerID");
				Double orderCost = record.getDouble("OrdertCustomerPrice");
				Double orderPrice = record.getDouble("OrdertBusinessPrice");
				String orderTimeStamp = record.getString("OrdertTimeStamp");
				Integer OrderCompleteState = record.getInt("IsCompleted");

				orders.add(
						new Order(orderId, customerId, orderType, orderTimeStamp, orderCost, orderPrice, OrderCompleteState));

			}
			conn.close();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}


		return orders;
	}

	public static ArrayList<Order> getCompletedOrders() throws SQLException, IOException {
		connect_to_db();
		/*
		 * Return an arraylist of all of the orders.
		 * 	openOnly == true => only return a list of open (ie orders that have not been marked as completed)
		 *           == false => return a list of all the orders in the database
		 * Remember that in Java, we account for supertypes and subtypes
		 * which means that when we create an arrayList of orders, that really
		 * means we have an arrayList of dineinOrders, deliveryOrders, and pickupOrders.
		 *
		 * Don't forget to order the data coming from the database appropriately.
		 *
		 */
		ArrayList<Order> orders = new ArrayList<Order>();

		try {
			connect_to_db();

			String selectQuery = "select * from ordert";

			selectQuery += " where (IsCompleted = True)";

			selectQuery += " order by OrdertTimeStamp desc;";

			Statement statement = conn.createStatement();

			ResultSet record = statement.executeQuery(selectQuery);

			while (record.next()) {
				Integer orderId = record.getInt("OrdertID");
				String orderType = record.getString("OrdertType");
				Integer customerId = record.getInt("OrdertCustomerID");
				Double orderCost = record.getDouble("OrdertCustomerPrice");
				Double orderPrice = record.getDouble("OrdertBusinessPrice");
				String orderTimeStamp = record.getString("OrdertTimeStamp");
				Integer OrderCompleteState = record.getInt("IsCompleted");

				orders.add(
						new Order(orderId, customerId, orderType, orderTimeStamp, orderCost, orderPrice, OrderCompleteState));

			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}


		//DO NOT FORGET TO CLOSE YOUR CONNECTION
		return orders;
	}

	public static ArrayList<Discount> getDiscountList() throws SQLException, IOException {
		/*
		 * Query the database for all the available discounts and
		 * return them in an arrayList of discounts.
		 *
		 */
		ArrayList<Discount> discs = new ArrayList<Discount>();

		//returns a list of all the discounts.
		try {
			connect_to_db();
			String getDiscountssql = "SELECT * FROM discount";
			PreparedStatement dpreparedStatement = conn.prepareStatement(getDiscountssql);
			ResultSet discount = dpreparedStatement.executeQuery();
			while (discount.next()) {
				int discountID = discount.getInt("DiscountID");
				String discountName = discount.getString("DiscountName");
				boolean isPercent = discount.getBoolean("IsPercent");
				double amount = discount.getDouble("DiscountValue");
				discs.add(new Discount(discountID, discountName, amount, isPercent));
			}
			conn.close();
		}catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		//DO NOT FORGET TO CLOSE YOUR CONNECTION
		return discs;
	}

	public static Discount findDiscountByName(String name){
		/*
		 * Query the database for a discount using it's name.
		 * If found, then return an OrderDiscount object for the discount.
		 * If it's not found....then return null
		 *
		 */


		return null;
	}


	public static ArrayList<Customer> getCustomerList() throws SQLException, IOException {
		connect_to_db();
		/*
		 * Query the data for all the customers and return an arrayList of all the customers.
		 * Don't forget to order the data coming from the database appropriately.
		 *
		 */
		ArrayList<Customer> customers = new ArrayList<Customer>();
		try {
			String sql = "SELECT * FROM customer";
			PreparedStatement preparedStatement = conn.prepareStatement(sql);

			ResultSet records = preparedStatement.executeQuery();
			while (records.next()) {
				int customerID = records.getInt("CustomerID");
				String firstName = records.getString("CustomerFirstName");
				String lastName = records.getString("CustomerLastName");
				String phoneNo = records.getString("CustomerPhoneNo");


				customers.add(
						new Customer(customerID, firstName, lastName, phoneNo));

			}
		}catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}


		//DO NOT FORGET TO CLOSE YOUR CONNECTION
		return customers;
	}

	public static Customer findCustomerByPhone(String phoneNumber){
		/*
		 * Query the database for a customer using a phone number.
		 * If found, then return a Customer object for the customer.
		 * If it's not found....then return null
		 *
		 */

		/*
		 * Query the data for all the customers and return an arrayList of all the customers.
		 * Don't forget to order the data coming from the database appropriately.
		 *
		 */
		return null;
	}


	public static ArrayList<Topping> getToppingList() throws SQLException, IOException {
		connect_to_db();
		/*
		 * Query the database for the aviable toppings and
		 * return an arrayList of all the available toppings.
		 * Don't forget to order the data coming from the database appropriately.
		 *
		 */
		ArrayList<Topping> toppings = new ArrayList<Topping>();
		try {
			connect_to_db();
			String sql = "SELECT * FROM topping";
			PreparedStatement preparedStatement = conn.prepareStatement(sql);

			ResultSet records = preparedStatement.executeQuery();
			while (records.next()) {
				int toppingID = records.getInt("ToppingID");
				String toppingName = records.getString("ToppingName");
				Double toppingCustomerPrice = records.getDouble("ToppingCustomerPrice");
				Double toppingBusinessPrice = records.getDouble("ToppingBusinessPrice");
				Double toppingQuantityForPersonal = records.getDouble("ToppingQuantityForPersonal");
				Double toppingQuantityForMediumUnits = records.getDouble("ToppingQuantityForMediumUnits");
				Double toppingQuantityForLargeUnits = records.getDouble("ToppingQuantityForLargeUnits");
				Double toppingQuantityForXLargeUnits = records.getDouble("ToppingQuantityForXLargeUnits");
				int toppingMinInvLvl = records.getInt("ToppingMinInvLvl");
				int toppingCurrentInvLvl = records.getInt("ToppingCurrentInvLvl");
				toppings.add(
						new Topping(toppingID,toppingName, toppingQuantityForPersonal,
								toppingQuantityForMediumUnits,toppingQuantityForLargeUnits,toppingQuantityForXLargeUnits,toppingCustomerPrice,toppingBusinessPrice,toppingMinInvLvl
								,toppingCurrentInvLvl));

			}
		}catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		return toppings;

	}

	public static Topping findToppingByName(String name){
		/*
		 * Query the database for the topping using it's name.
		 * If found, then return a Topping object for the topping.
		 * If it's not found....then return null
		 *
		 */


		return null;
	}


	public static void addToInventory(Topping t, double quantity) throws SQLException, IOException {
		/*
		 * Updates the quantity of the topping in the database by the amount specified.
		 *
		 * */
		try {
			connect_to_db();
			String sql = "UPDATE topping SET ToppingCurrentInvLvl = ToppingCurrentInvLvl+? WHERE ToppingID = ?";
			Connection conn = DBConnector.make_connection();
			PreparedStatement preparedStatement = conn.prepareStatement(sql);
			preparedStatement.setDouble(1, quantity);
			preparedStatement.setInt(2, t.getTopID());
			preparedStatement.executeUpdate();
			/*
			 * Adds toAdd amount of topping to topping t.
			 */
			conn.close();
		}catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}


		//DO NOT FORGET TO CLOSE YOUR CONNECTION
	}

	public static double getBaseCustPrice(String size, String crust) throws SQLException, IOException {
		connect_to_db();
		/*
		 * Query the database fro the base customer price for that size and crust pizza.
		 *
		 */
		double bprice = 0.0;
		// add code to get the base price (for the customer) for that size and crust pizza Depending on how
		// you store size & crust in your database, you may have to do a conversion
		try {
			String selectQuery = "select * from basepizza;";


			PreparedStatement statement = conn.prepareStatement(selectQuery);
			ResultSet record = statement.executeQuery(selectQuery);
			while (record.next()) {
				String crusttype = record.getString("BasePizzaCrustType");
				String sizebase = record.getString("BasePizzaSize");


				if (crusttype.equals(crust) && sizebase.equals(size)) {

					bprice = record.getDouble("BasePizzaCustomerPrice");
				}
			}
			conn.close();
		}catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}


		//DO NOT FORGET TO CLOSE YOUR CONNECTION
		return bprice;
	}

	public static double getBaseBusPrice(String size, String crust) throws SQLException, IOException {
		connect_to_db();
		/*
		 * Query the database fro the base business price for that size and crust pizza.
		 *
		 */
		double bcost = 0.0;
		// add code to get the base cost (for the business) for that size and crust pizza Depending on how
		// you store size and crust in your database, you may have to do a conversion
		try {
			String selectQuery = "select * from basepizza;";


			PreparedStatement statement = conn.prepareStatement(selectQuery);
			ResultSet record = statement.executeQuery(selectQuery);
			while (record.next()) {
				String crusttype = record.getString("BasePizzaCrustType");
				String sizebase = record.getString("BasePizzaSize");


				if (crusttype.equals(crust) && sizebase.equals(size)) {

					bcost = record.getDouble("BasePizzaBusinessPrice");
				}
			}
			conn.close();
		}catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		//DO NOT FORGET TO CLOSE YOUR CONNECTION
		return bcost;
	}

	public static void printInventory() throws SQLException, IOException {

		/*
		 * Queries the database and prints the current topping list with quantities.
		 *
		 * The result should be readable and sorted as indicated in the prompt.
		 *
		 */
		try {
			connect_to_db();

			String sql = "SELECT ToppingID, ToppingName, ToppingCurrentInvLvl FROM topping order by ToppingName";
			PreparedStatement preparedStatement = conn.prepareStatement(sql);
			ResultSet results = preparedStatement.executeQuery();

			while (results.next()) {
				System.out.println("ToppingID: " + results.getString("ToppingID") + " | Name: " + results.getString("ToppingName") + " | CurrentInvLvl: " + results.getString("ToppingCurrentInvLvl"));
			}

			conn.close();
		}catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}


		//DO NOT FORGET TO CLOSE YOUR CONNECTION


	}

	public static void printToppingPopReport() throws SQLException, IOException {
		connect_to_db();
		/*
		 * Prints the ToppingPopularity view. Remember that this view
		 * needs to exist in your DB, so be sure you've run your createViews.sql
		 * files on your testing DB if you haven't already.
		 *
		 * The result should be readable and sorted as indicated in the prompt.
		 *
		 */
		try {
			String maxOrdSql = "SELECT * FROM ToppingPopularity";
			PreparedStatement prepared = conn.prepareStatement(maxOrdSql);
			ResultSet report = prepared.executeQuery();
			int maxOrderID = -1;
			System.out.printf("%-20s  %-4s %n", "Topping", "ToppingCount");
			while (report.next()) {
				String topping = report.getString("Topping");
				Integer toppingCount = report.getInt("ToppingCount");
				System.out.printf("%-20s  %-4s %n", topping, toppingCount);
			}

			//DO NOT FORGET TO CLOSE YOUR CONNECTION
			conn.close();
		}catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}


		//DO NOT FORGET TO CLOSE YOUR CONNECTION
	}

	public static void printProfitByPizzaReport() throws SQLException, IOException {
		connect_to_db();
		/*
		 * Prints the ProfitByPizza view. Remember that this view
		 * needs to exist in your DB, so be sure you've run your createViews.sql
		 * files on your testing DB if you haven't already.
		 *
		 * The result should be readable and sorted as indicated in the prompt.
		 *
		 */
		try {
			String maxOrdSql = "SELECT * FROM ProfitByPizza";
			PreparedStatement prepared = conn.prepareStatement(maxOrdSql);
			ResultSet report = prepared.executeQuery();
			System.out.printf("%-15s  %-15s  %-10s %-30s%n", "Size", "Crust", "Profit", "OrderMonth");
			while (report.next()) {

				String size = report.getString("Size");
				String crust = report.getString("Crust");
				Double profit = report.getDouble("Profit");
				String orderDate = report.getString("OrderMonth");

				System.out.printf("%-15s  %-15s  %-10s %-30s%n", size, crust, profit, orderDate);

			}

			//DO NOT FORGET TO CLOSE YOUR CONNECTION
			conn.close();
		}catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}


		//DO NOT FORGET TO CLOSE YOUR CONNECTION
	}

	public static void printProfitByOrderType() throws SQLException, IOException {
		connect_to_db();
		/*
		 * Prints the ProfitByOrderType view. Remember that this view
		 * needs to exist in your DB, so be sure you've run your createViews.sql
		 * files on your testing DB if you haven't already.
		 *
		 * The result should be readable and sorted as indicated in the prompt.
		 *
		 */
		try {
			String maxOrdSql = "SELECT * FROM ProfitByOrderType";
			PreparedStatement prepared = conn.prepareStatement(maxOrdSql);
			ResultSet report = prepared.executeQuery();
			System.out.printf("%-15s  %-15s  %-18s %-18s %-8s%n", "CustomerType", "OrderMonth", "TotalOrderPrice",
					"TotalOrderCost", "Profit");
			while (report.next()) {

				String customerType = report.getString("CustomerType");
				String orderMonth = report.getString("OrderMonth");
				Double totalPrice = report.getDouble("TotalOrderPrice");
				Double totalCost = report.getDouble("TotalOrderCost");
				Double profit = report.getDouble("Profit");
				System.out.printf("%-15s  %-15s  %-18s %-18s %-8s%n", customerType, orderMonth, totalPrice,
						totalCost, profit);

			}

			//DO NOT FORGET TO CLOSE YOUR CONNECTION
			conn.close();
		}catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}


		//DO NOT FORGET TO CLOSE YOUR CONNECTION
	}
	public static int getMaxPizzaID() throws SQLException, IOException {
		int maxOrderID = -1;
		try {
			connect_to_db();
			String maxOrdSql = "SELECT * FROM pizza where PizzaID = (SELECT MAX(PizzaID) from pizza)";
			PreparedStatement maxOrderstmt = conn.prepareStatement(maxOrdSql);
			ResultSet maxOrder = maxOrderstmt.executeQuery();

			while (maxOrder.next())
				maxOrderID = Integer.parseInt(maxOrder.getString("PizzaID"));

		}catch (Exception e) {
			e.printStackTrace();
		}
		finally {
			try {
				conn.close();
			}
			catch (SQLException e) {
				e.printStackTrace();
			}
		}
		//DO NOT FORGET TO CLOSE YOUR CONNECTION
		return maxOrderID;




	}


	public static String getCustomerName(int CustID) throws SQLException, IOException {
		/*
		 * This is a helper method to fetch and format the name of a customer
		 * based on a customer ID. This is an example of how to interact with
		 * your database from Java.  It's used in the model solution for this project...so the code works!
		 *
		 * OF COURSE....this code would only work in your application if the table & field names match!
		 *
		 */

		connect_to_db();

		/*
		 * an example query using a constructed string...
		 * remember, this style of query construction could be subject to sql injection attacks!
		 *
		 */
		String cusname1 = "";
		String query = "Select CustomerFirstName, CustomerLastName From customer WHERE CustomerID=" + CustID + ";";
		Statement Stmt = conn.createStatement();
		ResultSet Rset = Stmt.executeQuery(query);

		while(Rset.next()) {
			cusname1 = Rset.getString(1) + " " + Rset.getString(2);
		}

		/*
		 * an example of the same query using a prepared statement...
		 *
		 */
		String cusname2 = "";
		PreparedStatement os;
		ResultSet Rset2;
		String query2;
		query2 = "Select CustomerFirstName, CustomerLastName From customer WHERE CustomerID=?;";
		os = conn.prepareStatement(query2);
		os.setInt(1, CustID);
		Rset2 = os.executeQuery();
		while(Rset2.next()) {
			cusname2 = Rset2.getString("CustomerFirstName") + " " + Rset2.getString("CustomerLastName"); // note the use of field names in the getSting methods
		}

		conn.close();
		return cusname1; // OR cname2
	}
	/*
	 * The next 3 private methods help get the individual components of a SQL datetime object.
	 * You're welcome to keep them or remove them.
	 */
	private static int getYear(String date)// assumes date format 'YYYY-MM-DD HH:mm:ss'
	{
		return Integer.parseInt(date.substring(0,4));
	}

	private static int getMonth(String date)// assumes date format 'YYYY-MM-DD HH:mm:ss'
	{
		return Integer.parseInt(date.substring(5, 7));
	}

	private static int getDay(String date)// assumes date format 'YYYY-MM-DD HH:mm:ss'
	{
		return Integer.parseInt(date.substring(8, 10));
	}

	public static boolean checkDate(int year, int month, int day, String dateOfOrder) {
		if(getYear(dateOfOrder) > year)
			return true;
		else if(getYear(dateOfOrder) < year)
			return false;
		else {
			if(getMonth(dateOfOrder) > month)
				return true;
			else if(getMonth(dateOfOrder) < month)
				return false;
			else {
				if(getDay(dateOfOrder) >= day)
					return true;
				else
					return false;
			}
		}
	}


}