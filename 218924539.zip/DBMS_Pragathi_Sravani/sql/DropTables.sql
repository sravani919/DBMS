-- Team 20: Sravani Pati,Pragathi Pendem
USE PIZZERIA_PS;

DROP TABLE dinein;
DROP TABLE delivery;
DROP TABLE pickup;
DROP TABLE orderdeals;
DROP TABLE specialpizzaoffer;
DROP TABLE discount;
DROP TABLE pizzatopping;
DROP TABLE pizza;
DROP TABLE ordert;
DROP TABLE customer;
DROP TABLE basepizza;
DROP TABLE topping;
DROP SCHEMA PIZZERIA_PS;