
-- Team 20: Sravani Pati,Pragathi Pendem
USE PIZZERIA_PS;
select * from customer;
select * from ordert;
select * from dinein;
select * from pickup;
select * from delivery;
select * from discount;
select * from orderdeals;
select * from basepizza ;
select * from pizza;
select * from specialpizzaoffer;
select * from topping;
select * from pizzatopping;

